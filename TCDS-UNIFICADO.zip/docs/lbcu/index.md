# LBCU — Ley de Balance Coherencial Universal
Portal del canon de cierre.
