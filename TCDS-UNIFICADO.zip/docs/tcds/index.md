# TCDS — Teoría Cromodinámica Sincrónica
Documentación base del paradigma TCDS.
